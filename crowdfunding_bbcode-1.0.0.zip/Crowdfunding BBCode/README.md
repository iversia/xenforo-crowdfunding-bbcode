XenForo-Crowdfunding-BBCode
===========================

Crowdfunding BB Code Media Pack for XenForo

Supported Sites
------------
* [Crowdfunder](http://www.crowdfunder.co.uk)
* [Indiegogo](http://www.indiegogo.com)
* [Kickstarter](http://www.kickstarter.com)
* [KissKissBankBank](http://www.kisskissbankbank.com)
* [Medstartr](http://www.medstartr.com)
* [RocketHub](http://www.rockethub.com)
* [Ulule](http://www.ulule.com)

Requirements
------------
* [XenForo](http://xenforo.com/) 1.1.3+

Copyright / License
------------

This project is released underneath the [DBAD PUBLIC LICENSE](http://www.dbad-license.org) by Phil Sturgeon.